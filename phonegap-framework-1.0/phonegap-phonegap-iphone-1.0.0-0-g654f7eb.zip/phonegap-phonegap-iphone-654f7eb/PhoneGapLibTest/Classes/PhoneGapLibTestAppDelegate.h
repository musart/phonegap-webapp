//
//  PhoneGapLibTestAppDelegate.h
//  PhoneGapLibTest
//
//  Created by shazron on 09-12-11.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface PhoneGapLibTestAppDelegate : PhoneGapDelegate {
}

@end

