package com.phonegap.file;

public class InvalidModificationException extends Exception {

	public InvalidModificationException(String message) {
		super(message);
	}

}
