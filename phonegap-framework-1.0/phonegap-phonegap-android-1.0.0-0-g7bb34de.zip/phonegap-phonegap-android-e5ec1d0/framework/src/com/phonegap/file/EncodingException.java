package com.phonegap.file;

public class EncodingException extends Exception {

	public EncodingException(String message) {
		super(message);
	}
	
}
