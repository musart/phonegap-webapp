package com.phonegap.file;

public class TypeMismatchException extends Exception {

	public TypeMismatchException(String message) {
		super(message);
	}

}
